from fastapi import FastAPI, Request, Response

from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import uvicorn
from database import SessionLocal, Base, engine
from helpers import init_placeholder

from routes import admin_routes, feed_routes, profile_routes, auth_routes, anunturi_routes, pages



app = FastAPI()
Base.metadata.create_all(bind=engine)

app.include_router(pages.api, tags=["pages"])
app.include_router(auth_routes.api, tags=["auth"])
app.include_router(profile_routes.api, prefix="/api", tags=["profile"])
app.include_router(anunturi_routes.api, prefix="/api", tags=["anunturi"])
app.include_router(feed_routes.api, prefix="/api", tags=["feed"])
app.include_router(admin_routes.api, prefix="/api", tags=["admin"])


app.mount("/static", StaticFiles(directory="static"), name="static")
app.mount("/uploads", StaticFiles(directory="uploads"), name="uploads")

templates = Jinja2Templates(directory="templates")


@app.middleware("http")
async def remove_headers(request: Request, call_next):
    response: Response = await call_next(request)
    
    # Remove ETag header if it exists
    if "etag" in response.headers:
        del response.headers["etag"]

    # Add Cache-Control headers
    response.headers.update({
        "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
        "Pragma": "no-cache",
        "Expires": "0"
    })

    return response


@app.exception_handler(404)
async def not_found(request, exc):
    return templates.TemplateResponse(
        "/pages/404.jinja2",
        {"request": request}
    )


if __name__ == "__main__":
    db = SessionLocal()
    init_placeholder(db)
    
    uvicorn.run(app, host="0.0.0.0", port=8000, server_header=False)
