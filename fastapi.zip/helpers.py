
import os
import shutil
from uuid import uuid4

from fastapi import HTTPException, UploadFile, status
from database import DBAd, DBUser

from fastapi.security import OAuth2PasswordBearer
from passlib.context import CryptContext
from sqlalchemy.orm import Session


pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")


def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def authenticate_user(db: Session, username: str, password: str):
    user = db.query(DBUser).filter(DBUser.username == username).first()
    if not user or not verify_password(password, user.password):
        return None
    return user



def is_auth(db: Session, cookie: str):
    if not cookie:
        # raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Not authenticated")
        return False
    
    user = db.query(DBUser).filter(DBUser.sesiune == cookie).first()
    if not user:
        # raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid session")
        return False
    
    return user


# def logout_user()


def init_placeholder(db: Session):
    if not db.query(DBUser).first():
        is_ok = create_user(
            db,
            username="admin", 
            password="admin",
            name="Administrator"
        )
        if is_ok:
            print(f"Added placeholder user: 'admin'")

    # Check if ads exist, if not, add placeholder ads
    if not db.query(DBAd).first():
        is_not_ad = create_ad(
            db,
            title="Sample Ad",
            description="This is a placeholder ad.",
            contact="Mesaj: 0727901420",
            city="faget",
            state="tm",
            user_id=1, # TO-DO: get user_id 
            cat=1
        )
        if is_not_ad:
            print(f"Added placeholder ad for: 'Faget'")



def create_user(
    db: Session,
    username: str, 
    password: str, 
    name: str,
    avatar_name : str = None
):
    db_user = DBUser(
        username=username, 
        password=pwd_context.hash(password),
        name=name,
        avatar_name=avatar_name
    )
    
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user



def create_ad(
    db: Session, 
    title: str, 
    description: str, 
    contact: str,
    city: str, 
    state: str,
    user_id: int,
    cat: int,
    image_name: str = None
):
    db_ad = DBAd(
        title=title, 
        description=description, 
        contact=contact,
        city=city,
        state=state, 
        image_name=image_name, 
        user_id=user_id,
        cat=cat
    )

    db.add(db_ad)
    db.commit()
    db.refresh(db_ad)
    return db_ad




def upload_file(media: UploadFile, user_id: int, is_avatar = False):
    file_extension = os.path.splitext(media.filename)[1]

    if is_avatar:
        media_filename = f"{user_id}{file_extension}"
        directory = os.path.join('uploads', 'avatars')
    else:
        media_filename = f"{uuid4().hex[:10]}{file_extension}"
        directory = os.path.join('uploads', 'ads', str(user_id))

    # Create directory if it does not exist
    os.makedirs(directory, exist_ok=True)

    file_path = os.path.join(directory, media_filename)
    
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(media.file, buffer)
    
    return media_filename



def delete_file(name, user_id: int):
    if not name:
        return True
    
    file_path = os.path.join('uploads', 'ads', str(user_id), name)
    try:
        if os.path.exists(file_path):
            os.remove(file_path)
            return True
        else:
            return False
    except Exception as e:
        # print(f"An error occurred while deleting the file: {e}")
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=e)
