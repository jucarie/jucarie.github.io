from fastapi import APIRouter, Depends, Query, HTTPException, status
from fastapi.responses import JSONResponse
from sqlalchemy import and_
from sqlalchemy.orm import Session

from database import DBAd, get_db



api = APIRouter()


# @api.get("/feed", response_model=dict)
# # TO-DO:
# # - sau cautare dupa categorie global
# # - filter dupa oras
# # - sterge 'Food Listings in Faget, TM'?
# # - css urat 
# async def get_feed(
#     city: str = Query(None, min_length=1, max_length=50),
#     state: str = Query(None, min_length=1, max_length=3),
#     cat: int = Query(0, ge=0, le=10),
#     sort: str = Query("newest"),
#     page: int = Query(1, ge=1),
#     per_page: int = Query(12, ge=1, le=100),
#     db: Session = Depends(get_db)
# ):

#     try:
#         if (city and not state) or (state and not city):
#             return JSONResponse(
#                 status_code=status.HTTP_409_CONFLICT,
#                 content={"detail": "Trebuie ambele ('city' si 'state')"}
#             )
        
#         # Base query: Published ads only
#         base_query = db.query(DBAd).filter(DBAd.publish == True)

#         if city and state:
#             base_query = base_query.filter(
#                 DBAd.city == city.lower(), DBAd.state == state.lower()
#             )

#         # Check if base query has results
#         total_items = base_query.count()
#         if total_items == 0:
#             return {
#                 "items": [],
#                 "pagination": {
#                     "current_page": 1,
#                     "per_page": per_page,
#                     "total_pages": 0,
#                     "total_items": 0,
#                 }
#             }


#         # ( 0 = get all from category)
#         if cat > 0:
#             base_query = base_query.filter(DBAd.cat == cat)


#         # Apply sorting
#         base_query = base_query.order_by(
#             DBAd.created_at.desc() if sort == "newest"
#             else DBAd.created_at.asc()
#         )

#         # Get total count efficiently
#         total_pages = max((total_items + per_page - 1) // per_page, 1)

#         # Validate page number
#         if page > total_pages:
#             return JSONResponse(
#                 status_code=404,
#                 content={"detail": f"Pagina {page} nu a fost gasita. Total pagini: {total_pages}"}
#             )
        
#         # Get paginated results
#         ads = (
#             base_query
#             .offset((page - 1) * per_page)
#             .limit(per_page)
#             .all()
#         )

#         return {
#             "items": [
#                 {
#                     "id": ad.id,
#                     "from_id": ad.user_id,
#                     "title": ad.title,
#                     "cat": ad.cat,
#                     "imageUrl": ad.image_name,
#                     "postedAt": ad.created_at.isoformat(),
#                     "location": {
#                         "city": ad.city.title(),
#                         "state": ad.state.upper(),
#                     }
#                 }
#                 for ad in ads
#             ],
#             "pagination": {
#                 "current_page": page,
#                 "per_page": per_page,
#                 "total_pages": total_pages,
#                 "total_items": total_items,
#             }
#         }

#     except Exception as e:
#         raise HTTPException(
#             status_code=500,
#             detail=f"Error 108: {str(e)}"
#         )


# @api.get("/feed", response_model=dict)
# async def get_feed():
#     raise HTTPException(status_code=400, detail=f"Locatie necunoscuta!")

@api.get("/feed", response_model=dict)
# TO-DO:
# - css urat scris
# - daca ceva din filtru ii selectat, atunci nu apare in url
# - cand nu ii poza, sa nu faca preview
async def get_feed(
    city: str = Query(None, min_length=1, max_length=50),
    # state: str = Query(None, min_length=1, max_length=3),
    cat: int = Query(0, ge=0, le=10),
    sort: str = Query("newest"),
    page: int = Query(1, ge=1),
    per_page: int = Query(12, ge=1, le=100),
    db: Session = Depends(get_db)
):

    try:
        # Base query: Published ads only
        base_query = db.query(DBAd).filter(DBAd.publish == True)

        if city and not city == "_toate":
            base_query = base_query.filter(DBAd.city == city.lower())

        # if state:
        #     base_query = base_query.filter(DBAd.state == state.lower())

        # ( 0 = get all from category)
        if cat > 0:
            base_query = base_query.filter(DBAd.cat == cat)


        # Check if base query has results
        total_items = base_query.count()
        if total_items == 0:
            return {
                "items": [],
                "pagination": {
                    "current_page": 1,
                    "per_page": per_page,
                    "total_pages": 0,
                    "total_items": 0,
                }
            }
        
        # Apply sorting
        base_query = base_query.order_by(
            DBAd.created_at.desc() if sort == "newest"
            else DBAd.created_at.asc()
        )

        # Get total count efficiently
        total_pages = max((total_items + per_page - 1) // per_page, 1)

        # Validate page number
        if page > total_pages:
            return JSONResponse(
                status_code=404,
                content={"detail": f"Pagina {page} nu a fost gasita. Total pagini: {total_pages}"}
            )
        
        # Get paginated results
        ads = (
            base_query
            .offset((page - 1) * per_page)
            .limit(per_page)
            .all()
        )

        return {
            "items": [
                {
                    "id": ad.id,
                    "from_id": ad.user_id,
                    "title": ad.title,
                    "cat": ad.cat,
                    "imageUrl": ad.image_name[0] if ad.image_name else None,
                    "postedAt": ad.created_at.isoformat(),
                    "location": {
                        "city": ad.city.title(),
                        "state": ad.state.upper(),
                    }
                }
                for ad in ads
            ],
            "pagination": {
                "current_page": page,
                "per_page": per_page,
                "total_pages": total_pages,
                "total_items": total_items,
            }
        }

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error 108: {str(e)}"
        )