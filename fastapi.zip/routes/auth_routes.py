from datetime import datetime, timedelta

import re
from typing import Literal
from uuid import uuid4
from fastapi import APIRouter, Depends,  status, Form, HTTPException, Request, Response
from fastapi.responses import JSONResponse, RedirectResponse

from sqlalchemy.orm import Session

from database import DBUser, get_db
from helpers import create_user, authenticate_user, is_auth



api = APIRouter()



@api.post("/register")
# TO-DO:
# - lower username si ad text in front end
async def register(
    name: str = Form(...),
    username: str = Form(...),
    password: str = Form(...),
    db: Session = Depends(get_db)
):
    # Regex patterns for validation
    REGEX_PATTERNS = {
        "name": r'^[A-Za-zaâîșț\s]{3,100}$',
        "username": r'^[a-zA-Z0-9_.]{3,50}$',
        "password": r'^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&._])[A-Za-z\d@$!%*#?&._]{6,128}$'
        # "contact_mobile": r'^(07[0-9]{8}|(\+4|04)[0-9]{9})$'
    }

    # Validation function
    def validate_field(field_name: str, value: str) -> bool:
        pattern = REGEX_PATTERNS.get(field_name)
        if not pattern:
            raise ValueError(f"No validation pattern for {field_name}")
        return re.match(pattern, value) is not None
    
    def add_error(message: str):
        validation_errors.append(f'Erroare 476:<br>"{message}"')

    validation_errors = []

    if not validate_field("name", name):
        add_error("Nume invalid. Doar litere, spatii.Limita 3-100 caractere.")

    if not validate_field("username", username):
        add_error("Username invalid. Folositi litere mici, cifre, punct, underline (_).Limita 3-50 caractere.")

    if not validate_field("password", password):
        add_error("Parola slaba. Necesita litera, cifra, caracter special (@$!%*#?&._).Limita 6-128 caractere.")


    if validation_errors:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, 
            detail=validation_errors
        )

    username = username.lower()
    try:
        if db.query(DBUser).filter(DBUser.username == username).first():
            # raise HTTPException(
            #     status_code=status.HTTP_409_CONFLICT, 
            #     detail="Username-ul exista deja"
            # )
            return JSONResponse(
                status_code=status.HTTP_409_CONFLICT,
                content={"detail": "Username-ul exista deja!"}
            )

        new_user = create_user(
            db,
            username=username,
            password=password,
            name=name
        )

        if new_user:
            return {"redirect_to": "/login"}

    except Exception as e:  
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, 
            detail=f"Eroare 92: {str(e)}"
        )
    





@api.post("/login")
async def login(
    response: Response,
    username: str = Form(...), 
    password: str = Form(...), 
    from_id: int = Form(None), 
    db: Session = Depends(get_db)
):
    user = authenticate_user(db, username, password)
    if not user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Username-ul sau parola gresita!")
    
    new_session = str(uuid4())
    user.sesiune = new_session
    db.commit()  
    
    expiration_time = datetime.now().astimezone() + timedelta(hours=8)
    response.set_cookie(
        key="session",
        value=new_session,
        httponly=True,
        expires=expiration_time.timestamp(),  
        samesite='Strict'
    )

    if from_id:
        redirect_to = f'/anunt/{from_id}'
    else:
        redirect_to = '/anunturile-mele'

    return {"detail": "Login successful. Redirecting...", "redirect_to": redirect_to}


