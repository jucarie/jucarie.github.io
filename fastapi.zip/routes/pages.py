import os
import re
from fastapi import APIRouter, Depends, HTTPException, Request, Response
from fastapi.responses import FileResponse, HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy import and_
from sqlalchemy.orm import Session

from database import  DBAd, DBUser, get_db
from helpers import is_auth


api = APIRouter()


templates = Jinja2Templates(directory="templates")


@api.get("/login", response_class=HTMLResponse)
async def login_url(
    request: Request,
    from_id: str = None,
    db: Session = Depends(get_db)
):
    try:
        if from_id:
            int(from_id)
    except ValueError:
        return RedirectResponse(url="/login", status_code=303)
    
    cookie = request.cookies.get("session")
    if is_auth(db, cookie):
        return RedirectResponse(url="/profile", status_code=303)
    
    # referer = request.headers.get("referer")
    # REFERER_PATTERN = re.compile(r"^https?://(www\.)?chatgpt\.com/anunt/")
    # REFERER_PATTERN = re.compile(r"^http://127\.0\.0\.1:8000/anunt/")

    return templates.TemplateResponse(
        "/pages/login.jinja2", 
        {"request": request, "from_id": from_id}
    )


@api.get("/logout")
async def logout(
    response: Response, 
    request: Request,
    db: Session = Depends(get_db)
):
    cookie = request.cookies.get("session")
    if cookie:
        current_user = is_auth(db, cookie)
        if current_user:
            current_user.sesiune = None  
            db.commit()  
        response.delete_cookie(key="session")

    return RedirectResponse(url="/login", status_code=303)


@api.get("/register", response_class=HTMLResponse)
# TO-DO: 
# - cand ies din password sa imi apara confirm_password,
# - sterge numele ?
# - are alt footer!!!!
async def register_url(request: Request):
    return templates.TemplateResponse(
        "pages/register.jinja2", 
        {"request": request}
    )


@api.get("/profile")
async def profile_url(
    request: Request, 
    db: Session = Depends(get_db)
):
    cookie = request.cookies.get("session")
    if not cookie or not is_auth(db, cookie):
        return RedirectResponse(url="/login", status_code=303)
    
    # file_path = os.path.join(os.getcwd(), 'static', 'user-info.html')
    # return FileResponse(file_path)
    return templates.TemplateResponse(
        "/pages/user-info.jinja2",
        {"request": request}
    )



@api.get("/anunturile-mele")
# TO-DO: 
# - https://sharingbuttons.io/ ?
# - ".image-preview-box .remove-image" : X (close) sa apara dupa ce incarca poza
async def ad_url(
    request: Request, 
    db: Session = Depends(get_db)
):
    cookie = request.cookies.get("session")
    if not cookie or not is_auth(db, cookie):
        return RedirectResponse(url="/login", status_code=303)
    
    current_user = is_auth(db, cookie)
    user_ads = db.query(DBAd).filter(DBAd.user_id == current_user.id).all()
    

    # file_path = os.path.join(os.getcwd(), 'static', 'user-listings.html')
    # return FileResponse(file_path)
    return templates.TemplateResponse(
        "/pages/user-listings.jinja2",
        {"request": request}
    )



@api.get("/admin-dash")
async def Admin_url(
    request: Request, 
    db: Session = Depends(get_db)
):
    cookie = request.cookies.get("session")
    if not cookie or not is_auth(db, cookie):
        return RedirectResponse(url="/login", status_code=303)
    
    current_user = is_auth(db, cookie)
    if current_user.username == "admin":
        file_path = os.path.join(os.getcwd(), 'static', 'admin-dash.html')
    else:
        file_path = os.path.join(os.getcwd(), 'static', 'user-listings.html')

    return FileResponse(file_path)




@api.get("/anunt/{id}")
# TO-DO: 
# - pe desktop butonul close nu ii centralizat
# - google captcha js include
# - daca ii fara img, atunci footer nu ii jos
async def get_ad_url(
    request: Request, 
    id: str,
    db: Session = Depends(get_db)
):
    try:
        int(id)
    except ValueError:
        raise HTTPException(status_code=404, detail="SqlInjection")
    

    current_user = None
    cookie = request.cookies.get("session")
    if cookie:
        current_user = is_auth(db, cookie)


    
    anunt = db.query(DBAd).filter(DBAd.publish == True, DBAd.id == id).first()
    if not anunt:
        raise HTTPException(status_code=404, detail="Ad not found")

    user = db.query(DBUser).filter(DBUser.id == anunt.user_id).first()

    return templates.TemplateResponse(
        "pages/detaliu_anunt.jinja2", 
        {"request": request, "anunt": anunt, "user": user, "isAuth": current_user}
    )



@api.get("/", response_class=HTMLResponse)
@api.get("/index.html", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse("/pages/index.jinja2", {"request": request})


    

@api.get("/feed", response_class=HTMLResponse)
# TO-DO:    
# - category pill, pe mobil, cand se selecteaza jump deoarece refresh !!!
# - mobile: adauga un buton in filtru sa nu se actualizeze ptr orice change
async def feed_url(request: Request):
    return templates.TemplateResponse(
        "/pages/feed.jinja2",
        {"request": request}
    )
