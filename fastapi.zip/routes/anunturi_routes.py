
from typing import Optional
from fastapi import APIRouter, Depends, status, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import JSONResponse
from sqlalchemy.orm import Session

from database import DBAd, DBUser, get_db
from helpers import create_ad, upload_file, delete_file, is_auth


api = APIRouter()


@api.get("/anunturi", response_model=dict)
async def get_anunturi(request: Request, db: Session = Depends(get_db)):


    cookie = request.cookies.get("session")
    if not cookie:
        raise HTTPException(status_code=400, detail="Authentication cookie is missing")

    current_user = is_auth(db, cookie)
    if not current_user:
        raise HTTPException(status_code=403, detail="Unauthorized access")

    # user = db.query(DBUser).filter(DBUser.id == current_user.id).first()

    query = db.query(DBAd).filter(DBAd.user_id == current_user.id).all()

    # Separate the ads into published and drafted lists
    published = [ad for ad in query if ad.publish]
    drafted = [ad for ad in query if not ad.publish]

    return {
        "publish": [
            {
                "id": ad.id,
                "title": ad.title,
                "cat": ad.cat,
                "location": {
                    "city": ad.city.title(),
                    "state": ad.state.title()
                }
            }
            for ad in published
        ],
        "draft": [
            {
                "id": ad.id,
                "title": ad.title,
                "cat": ad.cat,
                "location": {
                    "city": ad.city.title(),
                    "state": ad.state.title()
                }
            }
            for ad in drafted
        ]
    }



@api.post("/anunturi", status_code=200)
#TO-DO: 
# - deoarrece sunt multe imagini, create another for the main image to be mobil resp (feed)
async def post_anunt(
    request: Request, 
    title: str = Form(..., min_length=4, max_length=100), 
    description: str = Form(..., min_length=5, max_length=1000), 
    contact: str = Form(..., min_length=4, max_length=100), 
    city: str = Form(..., min_length=1, max_length=50),
    state: str = Form(..., min_length=1, max_length=3),
    cat: int = Form(0, ge=1, le=10),
    image0: Optional[UploadFile] = File(None),
    image1: Optional[UploadFile] = File(None),
    image2: Optional[UploadFile] = File(None),
    db: Session = Depends(get_db)
):  
    
    if cat not in range(1, 5):
        raise HTTPException(status_code=400, detail="Categorie invalida!")
    
    city = city.lower()
    state = state.lower()

    if city not in ["faget", "debug"] or state not in ["tm", "debug"]:
        raise HTTPException(status_code=400, detail=f"Locatie necunoscuta!")

    cookie = request.cookies.get("session")
    if not cookie:
        raise HTTPException(status_code=400, detail="Authentication cookie is missing")

    current_user = is_auth(db, cookie)
    if not current_user:
        raise HTTPException(status_code=403, detail="Unauthorized access")

    image_names = []
    for idx, image in enumerate([image0, image1, image2], start=1):
        if image and image.size != 0:
            if image.size > (5 * 1024 * 1024):  # Set the limit to 5 MB
                raise HTTPException(status_code=400, detail=f"Imagine {idx} depaseste limita de 5 MB!")
            
            if not image.filename.lower().endswith(('.jpg', '.jpeg', '.png')):
                raise HTTPException(status_code=400, detail=f"Format imagine {idx} nepermis!")
            
            # Upload and validate the image
            check_file = upload_file(image, current_user.id)
            if not check_file:
                raise HTTPException(status_code=404, detail=f"Imaginea {idx} nu a fost uploadata!")
            
            image_names.append(check_file)

    anunt = create_ad(
        db,
        title=title,
        description=description,
        city=city,
        state=state,
        contact=contact,
        image_name=image_names,
        user_id=current_user.id, 
        cat=cat
    )

    return {"message": "Ad created successfully", "ad": anunt}




@api.delete("/anunturi/{ad_id}")
async def sterge_anunt(
    request: Request, 
    ad_id: int,
    db: Session = Depends(get_db)
):
    cookie = request.cookies.get("session")
    if not cookie:
        raise HTTPException(status_code=400, detail="Authentication cookie is missing")

    current_user = is_auth(db, cookie)
    if not current_user:
        raise HTTPException(status_code=403, detail="Unauthorized access")


    ad = db.query(DBAd).filter(DBAd.id == ad_id).first()
    if not ad:
        raise HTTPException(status_code=404, detail="Ad not found")

    if ad.user_id != current_user.id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not authorized to delete this ad")


    # Handle multiple file deletions
    image_names = ad.image_name if isinstance(ad.image_name, list) else [ad.image_name]
    failed_deletions = []

    for image_name in image_names:
        check_file = delete_file(image_name, current_user.id)
        if not check_file:
            failed_deletions.append(image_name)

    if failed_deletions:
        raise HTTPException(
            status_code=404,
            detail=f"Failed to delete the following files: {', '.join(failed_deletions)}"
        )
    
    db.delete(ad)
    db.commit()
    
    return {"message": "Ad deleted successfully"}




@api.post("/anunturi/change", status_code=200)
# TO-DO:
# - whenfrom draft to active,change create_data
async def update_status_anunt(
    request: Request, 
    ad_id: int = Form(..., ge=1, le=10),
    db: Session = Depends(get_db)
):  

    cookie = request.cookies.get("session")
    if not cookie:
        raise HTTPException(status_code=400, detail="Authentication cookie is missing")

    current_user = is_auth(db, cookie)
    if not current_user:
        raise HTTPException(status_code=403, detail="Unauthorized access")

    get_ad = db.query(DBAd).filter(DBAd.id == ad_id, DBAd.user_id == current_user.id).first()
    if not get_ad:
        raise HTTPException(status_code=404, detail="Advertisement not found or access denied")

    get_ad.publish = not get_ad.publish

    db.commit()

    return {"message": "Advertisement updated successfully", "status": get_ad.publish}



@api.post("/anunturi/contact", status_code=200)
# TO-DO:
# - google captcha
async def get_mobil_anunt(
    request: Request, 
    # ad_id: int = Form(..., ge=1, le=10),
    ad_id: int = Form(...),
    db: Session = Depends(get_db)
):  

    cookie = request.cookies.get("session")
    if not cookie:
        return JSONResponse(
            status_code=status.HTTP_409_CONFLICT,
            content={"detail": "Erroare 218: Necesita autentificare, se redirectioneaza...", "redirect_to": "/login"}
        )

    current_user = is_auth(db, cookie)
    if not current_user:
        return JSONResponse(
            status_code=status.HTTP_409_CONFLICT,
            content={"detail": "Erroare 222: Necesita autentificare, se redirectioneaza...", "redirect_to": "/login"}
        )

    get_ad = db.query(DBAd).filter(DBAd.id == ad_id).first()
    if not get_ad:
        return JSONResponse(
            status_code=status.HTTP_409_CONFLICT,
            content={"detail": "Anuntul nu a fost gasit!"}
        )

    return {"contact_message": get_ad.contact}