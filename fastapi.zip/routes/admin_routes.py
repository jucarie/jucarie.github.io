import shutil
from fastapi import APIRouter, Depends, Form, HTTPException, Request
from fastapi.responses import JSONResponse,  RedirectResponse
from sqlalchemy.orm import Session

from database import  DBAd, DBUser, get_db
from helpers import is_auth


api = APIRouter()


@api.get("/admin-dash", status_code=200)
async def Admin_api(
    request: Request, 
    db: Session = Depends(get_db)
):
    cookie = request.cookies.get("session")
    if not cookie or not is_auth(db, cookie):
        return RedirectResponse(url="/login", status_code=303)
    
    current_user = is_auth(db, cookie)
    if current_user.username != "admin":
        return JSONResponse({"error": "Unauthorized access"}, status_code=403)
    
    user_count = db.query(DBUser).count()
    active_ads_count = db.query(DBAd).filter(DBAd.publish == True).count()
    draft_ads_count = db.query(DBAd).filter(DBAd.publish == False).count()

    total_storage, used_storage, available_storage = shutil.disk_usage("/")

    dashboard_data = {
        "user_count": user_count,
        "active_ads_count": active_ads_count,
        "draft_ads_count": draft_ads_count,
        "storage": {
            "total": total_storage,
            "used": used_storage,
            "available": available_storage
        }
    }

    return dashboard_data



@api.get("/recent-activity")
async def get_recent_activity(
    request: Request, 
    db: Session = Depends(get_db),
    page: int = Form(1, ge=1),
    per_page: int = Form(12, ge=1, le=100),
    ):

    cookie = request.cookies.get("session")
    if not cookie or not is_auth(db, cookie):
        return RedirectResponse(url="/login", status_code=303)
    
    current_user = is_auth(db, cookie)
    if current_user.username != "admin":
        return JSONResponse({"error": "Unauthorized access"}, status_code=403)


    try:
        base_query = db.query(DBAd).filter(DBAd.publish == True)

        total_items = base_query.count()

        if total_items == 0:
            return {
                "items": [],
                "pagination": {
                    "current_page": 1,
                    "per_page": per_page,
                    "total_pages": 0,
                    "total_items": 0,
                }
            }

        base_query = base_query.order_by(DBAd.created_at.desc())

        # Get total count efficiently
        total_pages = max((total_items + per_page - 1) // per_page, 1)

        # Validate page number
        if page > total_pages:
            return JSONResponse(
                status_code=404,
                content={"detail": f"Pagina {page} nu a fost gasita. Total pagini: {total_pages}"}
            )
        
        # Get paginated results
        ads = (
            base_query
            .offset((page - 1) * per_page)
            .limit(per_page)
            .all()
        )

        return {
            "items": [
                {
                    "title": ad.title,
                    "timp": ad.created_at,
                }
                for ad in ads
            ],
            "pagination": {
                "current_page": page,
                "per_page": per_page,
                "total_pages": total_pages,
                "total_items": total_items,
            }
        }

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error 108: {str(e)}"
        )



    # activities = [
    #     {
    #         "title": 'shared "Fresh Apples"',
    #         "timp": "10 min ago"
    #     },
    #     {
    #         "title": 'listed "Used Books"',
    #         "timp": "1 hour ago"
    #     },
    #     {
    #         "title": 'shared "Cooked Meals"',
    #         "timp": "2 hours ago"
    #     }
    # ]
    # return activities


