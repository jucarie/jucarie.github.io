from typing import Optional
from fastapi import APIRouter, Depends,  File, Form, HTTPException, Request, UploadFile
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session

from database import DBUser, get_db
from helpers import upload_file, is_auth



api = APIRouter()


@api.post("/profile")
async def update_profile(
    request: Request, 
    db: Session = Depends(get_db),
    name: str = Form(...),
    avatar_file: Optional[UploadFile] = File(None),
    change_avatar: str = Form(None)
):
    cookie = request.cookies.get("session")
    if not cookie or not is_auth(db, cookie):
        return RedirectResponse(url="/login", status_code=303)
    
    current_user = is_auth(db, cookie)
    user = db.query(DBUser).filter(DBUser.id == current_user.id).first()

    # phone_pattern = r'^(07[0-9]{8}|(\+4|04)[0-9]{9})$' 
    # if not re.match(phone_pattern, contact_mobile):
    #     raise HTTPException(status_code=404, detail=f"Formatul telefon mobil incorect")
    
    # Update user fields
    user.name = name

    # Avatar file upload
    if not change_avatar and avatar_file and avatar_file.size != 0:
        if avatar_file.size > (3 * 1024 * 1024):  # Set the limit to 3 MB
            raise HTTPException(status_code=400, detail="Continutul avatar-ului depaseste limita de 3 MB!")
        
        if not avatar_file.filename.endswith(('.jpg', '.jpeg', '.png')):
            raise HTTPException(status_code=400, detail="Format imagine nepermis!")
        
        user.avatar_name = upload_file(avatar_file, current_user.id, is_avatar=True)
    

    db.commit()
    db.refresh(user)

    return {"message": "Actualizare reusita"}



@api.get("/profile", response_model=dict)
async def get_profile(request: Request, db: Session = Depends(get_db)):

    cookie = request.cookies.get("session")
    if not cookie or not is_auth(db, cookie):
        raise HTTPException(status_code=401, detail="Unauthorized")


    current_user = is_auth(db, cookie)
    user = db.query(DBUser).filter(DBUser.id == current_user.id).first()

    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    # Return user data
    return {
        "name": user.name,
        "avatar_name": user.avatar_name
    }


