from sqlalchemy import JSON, Boolean, DateTime, create_engine, func
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship
from sqlalchemy import Column, Integer, String, ForeignKey, Text


DATABASE_URL = "sqlite:///./test.sqlite"

engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()




class DBUser(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    sesiune = Column(String(255))
    
    username = Column(String(50), unique=True, index=True)
    password = Column(String(128))
    name = Column(String(100))
    avatar_name = Column(String(255), nullable=True)  

    # Define the relationship to the Ad model
    ads = relationship("DBAd", back_populates="user")


class DBAd(Base):
    __tablename__ = "ads"

    id = Column(Integer, primary_key=True, index=True)
    created_at = Column(DateTime, default=func.now()) 

    title = Column(String(100), nullable=False)  
    description = Column(String(1000), nullable=False)
    contact = Column(String(255), nullable=True) # change to 100
    city = Column(String(50), index=True, nullable=False) 
    state = Column(String(3), index=True, nullable=False)  
    cat = Column(Integer, default=0)

    image_name = Column(JSON, nullable=True)

    publish = Column(Boolean, default=True)
    user_id = Column(Integer, ForeignKey("users.id"))

    # Define the relationship to the User model
    user = relationship("DBUser", back_populates="ads")


Base.metadata.create_all(bind=engine)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()